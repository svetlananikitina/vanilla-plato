$('.multiple-items').slick({
  infinite: false,
  slidesToShow: 4,
  slidesToScroll: 1,
  arrows: true,
  nextArrow: '<i class="fa fa-chevron-right"></i>',
  prevArrow: '<i class="fa fa-chevron-left"></i>',
});
$('.tv-shows').slick({
  infinite: false,
  slidesToShow: 7,
  slidesToScroll:1,
  nextArrow: '<i class="fa fa-chevron-right"></i>',
  prevArrow: '<i class="fa fa-chevron-left"></i>'
});