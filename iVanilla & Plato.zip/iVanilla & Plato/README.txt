A Pen created at CodePen.io. You can find this one at http://codepen.io/-J0hn-/pen/mWwajN.

 Tutorial from codingphase https://www.youtube.com/watch?v=r8HYZ_nDf7A&list=PL_ZUs2eBjBittMJSkbLCIdN_BGYK95v14